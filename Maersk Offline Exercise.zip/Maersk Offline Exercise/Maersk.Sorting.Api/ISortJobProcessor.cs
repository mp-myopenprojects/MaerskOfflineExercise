﻿using System.Threading.Tasks;
using System;

namespace Maersk.Sorting.Api
{
    public interface ISortJobProcessor
    {
        Task<SortJob> Process(SortJob job);
        Task<SortJob> EnqueueJobAsync(SortJob job);
        Task<SortJob> GetJobAsync(Guid jobId);
        Task<SortJob[]> GetJobsAsync();
    }
}