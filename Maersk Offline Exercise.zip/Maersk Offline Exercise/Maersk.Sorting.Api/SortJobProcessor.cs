﻿using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;
using System.Collections.Generic;

namespace Maersk.Sorting.Api
{
    public class SortJobProcessor : ISortJobProcessor
    {
        private readonly ILogger<SortJobProcessor> _logger;
        private readonly IMemoryCache _memoryCache;

        public SortJobProcessor(ILogger<SortJobProcessor> logger, IMemoryCache memoryCache)
        {
            _logger = logger;
            _memoryCache = memoryCache;
        }

        public async Task<SortJob> Process(SortJob job)
        {
            _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);

            var stopwatch = Stopwatch.StartNew();

            var output = job.Input.OrderBy(n => n).ToArray();
            await Task.Delay(5000); // NOTE: This is just to simulate a more expensive operation

            var duration = stopwatch.Elapsed;

            _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);

            return new SortJob(
                id: job.Id,
                status: SortJobStatus.Completed,
                duration: duration,
                input: job.Input,
                output: output);
        }

        public async Task<SortJob> EnqueueJobAsync(SortJob job)
        {
            _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);

            if (_memoryCache.TryGetValue("listOfJob", out List<SortJob> listofjob))
            {
                listofjob.Add(job);
                _memoryCache.Set("listOfJob", listofjob);
            }
            else
            {
                List<SortJob> sortJobs = new List<SortJob>();
                sortJobs.Add(job);
                _memoryCache.Set("listOfJob", sortJobs);
            }

            await SortArray();

            return job;
        }

        public async Task<SortJob> GetJobAsync(Guid jobId)
        {
            _logger?.LogInformation("Querying specific job");

            SortJob job = new SortJob(jobId, SortJobStatus.Pending, null, new List<int>(), null);

            if (_memoryCache.TryGetValue("listOfJob", out List<SortJob> listofjob))
            {
                job = await Task.Run(() => listofjob.FirstOrDefault(p => p.Id == jobId));
            }

            return job;
        }

        public async Task<SortJob[]> GetJobsAsync()
        {
            List<SortJob> sortJobs = new List<SortJob>();

            _logger?.LogInformation("Querying all jobs");

            if (_memoryCache.TryGetValue("listOfJob", out List<SortJob> listofjob))
            {
                sortJobs = await Task.Run(() => listofjob);
            }
            return sortJobs.ToArray();
        }

        private async Task SortArray()
        {
            if (_memoryCache.TryGetValue("listOfJob", out List<SortJob> listofjob))
            {
                foreach (var job in listofjob.ToList())
                {
                    if (job.Status == SortJobStatus.Pending)
                    {
                        _logger.LogInformation("Processing job with ID '{JobId}'.", job.Id);
                        var stopwatch = Stopwatch.StartNew();

                        var output = await Task.Run(() => job.Input.OrderBy(n => n).ToArray());
                        var duration = stopwatch.Elapsed;

                        _logger.LogInformation("Completed processing job with ID '{JobId}'. Duration: '{Duration}'.", job.Id, duration);

                        var updatedJob = new SortJob(
                           id: job.Id,
                           status: SortJobStatus.Completed,
                           duration: duration,
                           input: job.Input,
                           output: output);

                        listofjob.Remove(job);
                        listofjob.Add(updatedJob);

                        _memoryCache.Set("listOfJob", listofjob);
                    }
                }
            }

        }
    }
}
